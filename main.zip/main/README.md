Jeu "jumping frog" utilisant la bibliothèque Pygame de Python.
